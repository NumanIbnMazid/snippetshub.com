$(document).ready(function () {

    $(function () {
        if ($('.ez-view').length) {
            $('.ez-view').EZView();
        }
    });

});
